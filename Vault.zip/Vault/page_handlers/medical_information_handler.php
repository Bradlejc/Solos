<?php

$error_array = [];

date_default_timezone_set('America/New_York');

if (isset($_POST['medical_information_btn'])) {

  $user_id = $user['id'];

  // need to validate fields TO DO

  $health_insurance_number = $_POST['health_insurance_number'];
  $medical_advocate = $_POST['medical_advocate'];
  $blood_type = $_POST['blood_type'];
  $medical_conditions = $_POST['medical_conditions'];
  $medications = $_POST['medications'];
  $allergies = $_POST['allergies'];
  $primary_care_physician = $_POST['primary_care_physician'];
  $preferred_hospital = $_POST['preferred_hospital'];
  $preferred_pharmacy = $_POST['preferred_pharmacy'];
  $family_health_history = $_POST['family_health_history'];
  $organ_donation = $_POST['organ_donation'];

  $date = date('Y-m-d H:i:s');

  $medical_conditions = implode(",", $medical_conditions);
  $medications = implode(",", $medications);
  $allergies = implode(",", $allergies);

  // update fields TO DO

  $query = mysqli_query($conn, "INSERT INTO medical_information VALUES ('$user_id', 
      '$health_insurance_number', '$medical_advocate', '$blood_type', '$medical_conditions', '$medications', '$allergies', 
      '$primary_care_physician', '$preferred_hospital', '$preferred_pharmacy', '$family_health_history', 
      '$organ_donation', '$date')");

  array_push($error_array, '<div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        Record Saved!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>');

}

?>